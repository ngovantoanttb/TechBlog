<?php
/**
 * Template part for displaying posts in a grid layout (Homepage style)
 *
 * @package TechJournal
 * @since 1.0.0
 */

$category_to_show = techblog_get_post_primary_category();
?>
<article class="group flex flex-col cursor-pointer transition-all duration-300">
    <!-- Image container with absolute Category Badge overlay -->
    <a href="<?php the_permalink(); ?>" class="aspect-[16/10] overflow-hidden block relative bg-slate-950 shrink-0">
        <?php echo techblog_render_post_thumbnail( get_the_ID(), 'techjournal-card', 'w-full h-full object-cover transition-transform duration-750 group-hover:scale-102 opacity-95 group-hover:opacity-100' ); ?>
        <?php if ($category_to_show) : ?>
            <span class="absolute bottom-3 left-3 bg-red-600 text-white text-[10px] sm:text-[9px] font-black uppercase px-2.5 py-1 tracking-widest shadow-sm">
                <?php echo esc_html($category_to_show->name); ?>
            </span>
        <?php endif; ?>
    </a>
    <div class="pt-4 flex flex-col flex-grow">
        <h3 class="font-display text-base text-slate-805 group-hover:text-primary transition-colors font-bold leading-snug mb-3.5 break-words">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        
        <!-- Date and Clock at the bottom -->
        <div class="flex items-center gap-2 text-xs text-slate-500 font-medium mt-auto flex-wrap">
            <span class="flex items-center gap-1">
                <?php echo techjournal_get_svg( 'clock', 'w-4 h-4 text-slate-500 fill-current' ); ?>
                <span><?php echo get_the_date('d/m/Y'); ?></span>
            </span>
            <?php if ( get_the_modified_time( 'U' ) > get_the_time( 'U' ) + 60 ) : ?>
                <span>•</span>
                <span>update <?php echo get_the_modified_date('d/m/Y'); ?></span>
            <?php endif; ?>
        </div>
    </div>
</article>
