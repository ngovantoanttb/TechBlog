<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * Reuses the layout of home.php.
 *
 * @package TechJournal
 * @since 1.0.0
 */

require get_template_directory() . '/home.php';
